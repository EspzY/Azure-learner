const fs=require('node:fs'),vm=require('node:vm'),{createRequire}=require('node:module');
const req=createRequire('/workspace/Azure-learner/package.json'),ts=req('typescript');
const app='/workspace/Azure-learner/',root=__dirname;
function load(path){const mod={exports:{}};const src=fs.readFileSync(app+path,'utf8');const js=ts.transpileModule(src,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;vm.runInNewContext(js,{module:mod,exports:mod.exports,require:()=>({}),console},{filename:path});return mod.exports;}
const nb=load('src/content/nb.ts'),transfer=load('src/domain/curriculum/transfer.ts'),sl=load('src/domain/curriculum/serverless.ts'),v2=load('src/domain/curriculum/foundations-v2.ts');
const p=JSON.parse(fs.readFileSync(root+'/student-packet.json','utf8')),out={generated_at:new Date().toISOString(),comparison_kind:'Post-lock source-level comparison; not a browser submission',ordinary:[],terminal:[],computing_key:v2.v2Criteria,serverless_key:sl.serverlessCriteria};
for(const family of ['benefits','services']){
 const prior=p.ordinary_assessments.find(x=>x.family===family),items=nb.refinedAssessmentNb.items[family];
 for(let i=0;i<items.length;i++){
  const item=items[i],old=prior.scenarios[i],rule=nb.refinedAssessmentNb.feedback[item.id];
  const proposed=old.proposed_pairs.map(pair=>{
   const d=item.decisions.find(x=>x.text===pair.decision)?.id,r=item.reasons.find(x=>x.text===pair.reason)?.id;
   return {decision:pair.decision,reason:pair.reason,ids:[d,r],accepted:rule.pairs.some(([dd,rr])=>dd===d&&rr===r)};
  });
  out.ordinary.push({family,id:item.id,version:family==='services'?'3.0.0':'2.0.0',proposed,accepted_pairs:rule.pairs,number:item.id==='b-capacity'?old.proposed_numeric_answer:null});
 }
}
for(const old of p.terminal_transfer_cases){
 const id=Object.keys(transfer.transferVariants).find(k=>transfer.transferVariants[k]===old.scenario_id),rule=transfer.transferItems[id];
 const proposed=old.proposed_pairs.map(pair=>{const d=old.decision_choices.indexOf(pair.decision),r=old.reason_choices.indexOf(pair.reason);return {...pair,zero_based_indices:[d,r],accepted:rule.accepted.some(([dd,rr])=>dd===d&&rr===r)};});
 out.terminal.push({case:old.scenario_id,id,version:rule.version,rubric:rule.rubric,proposed,accepted_pairs:rule.accepted});
}
out.summary={ordinary_items:out.ordinary.length,ordinary_proposed_pairs:out.ordinary.reduce((n,x)=>n+x.proposed.length,0),ordinary_all_pairs_accepted:out.ordinary.every(x=>x.proposed.every(p=>p.accepted)),terminal_items:out.terminal.length,terminal_proposed_pairs:out.terminal.reduce((n,x)=>n+x.proposed.length,0),terminal_all_pairs_accepted:out.terminal.every(x=>x.proposed.every(p=>p.accepted))};
fs.writeFileSync(root+'/postlock-key-comparison.json',JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify(out.summary));
