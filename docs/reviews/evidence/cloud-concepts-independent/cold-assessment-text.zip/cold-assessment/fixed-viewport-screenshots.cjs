const {createRequire}=require('node:module');
const fs=require('node:fs');
const req=createRequire('/workspace/Azure-learner/package.json');
const {chromium}=req('playwright');
const base='https://azure-learner-git-codex-az900-cloud-comp-3bf852-espzys-projects.vercel.app';
const root=__dirname;
const log=x=>fs.appendFileSync(root+'/viewport-actions.jsonl',JSON.stringify({...x,time:new Date().toISOString()})+'\n');
(async()=>{
 const browser=await chromium.launch({headless:true});
 const cases=[
  {id:'computing',route:'/learn/computing?topic=v2-assessment',start:['Start endret oppgave'],focus:'Hvor mange pakker er udekket i pilotens travleste time?'},
  {id:'benefits',route:'/learn/benefits?topic=assessment',start:['Start uassistert vurdering','Start vurderingen'],focus:'1. Kampanje med fast kapasitet'},
  {id:'services',route:'/learn/services?topic=assessment',start:['Start uassistert vurdering','Start vurderingen'],focus:'5. To gjennomførbare forslag'},
  {id:'serverless',route:'/learn/computing?topic=serverless-assessment',start:['Start selvstendig forsøk'],focus:'A · Ujevne webhook-varsler'}
 ];
 for(const item of cases){
  const ctx=await browser.newContext({viewport:{width:1440,height:900}});
  const page=await ctx.newPage();
  page.on('requestfailed',r=>log({kind:'requestfailed',url:r.url(),failure:r.failure()}));
  await page.goto(base+item.route,{waitUntil:'networkidle'});log({kind:'navigate',id:item.id,url:page.url()});
  for(const name of item.start){await page.getByRole('button',{name,exact:true}).click();log({kind:'click',id:item.id,name});}
  await page.getByText(item.focus,{exact:true}).scrollIntoViewIfNeeded();
  const f=root+'/viewport-'+item.id+'-1440x900.png';await page.screenshot({path:f,fullPage:false});log({kind:'screenshot',id:item.id,path:f,url:page.url(),width:1440,height:900});
  await page.setViewportSize({width:1024,height:500});await page.getByText(item.focus,{exact:true}).scrollIntoViewIfNeeded();
  const small=root+'/viewport-'+item.id+'-1024x500.png';await page.screenshot({path:small,fullPage:false});log({kind:'screenshot',id:item.id,path:small,url:page.url(),width:1024,height:500});
  await ctx.close();console.log(item.id+' viewport capture complete');
 }
 await browser.close();
})().catch(e=>{log({kind:'error',message:e.message});console.error(e);process.exitCode=1});
