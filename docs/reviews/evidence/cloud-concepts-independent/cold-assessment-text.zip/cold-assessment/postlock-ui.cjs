const {createRequire}=require('node:module');
const fs=require('node:fs');
const req=createRequire('/workspace/Azure-learner/package.json');
const {chromium}=req('playwright');
const root=__dirname, base='https://azure-learner-git-codex-az900-cloud-comp-3bf852-espzys-projects.vercel.app';
const packet=JSON.parse(fs.readFileSync(root+'/student-packet.json','utf8'));
const log=x=>fs.appendFileSync(root+'/postlock-actions.jsonl',JSON.stringify({...x,time:new Date().toISOString()})+'\n');
let browser;
async function capture(page,label){
 const png=root+'/postlock-'+label+'.png';await page.screenshot({path:png,fullPage:true});
 const text=await page.locator('body').innerText();
 fs.writeFileSync(root+'/postlock-'+label+'.txt',text);
 const buttons=await page.getByRole('button').evaluateAll(els=>els.filter(e=>e.getClientRects().length).map(e=>({text:e.innerText,disabled:e.disabled})));
 const links=await page.getByRole('link').evaluateAll(els=>els.filter(e=>e.getClientRects().length).map(e=>({text:e.innerText,href:e.getAttribute('href')})));
 log({kind:'capture',label,url:page.url(),text,buttons,links});
 console.log(JSON.stringify({label,url:page.url(),text,buttons,links}));
}
(async()=>{
 browser=await chromium.launch({headless:true});
 const tasks=process.argv.slice(2);
 for(const task of tasks){
  const context=await browser.newContext({viewport:{width:1440,height:900}}),page=await context.newPage();
  page.on('requestfailed',r=>log({kind:'requestfailed',task,url:r.url(),failure:r.failure()}));
  if(task.startsWith('services-')){
   await page.goto(base+'/learn/services?topic=assessment&version=2&assessment=updated',{waitUntil:'networkidle'});
   log({kind:'navigate',task,url:page.url()});
   await page.getByRole('button',{name:'Start uassistert vurdering',exact:true}).click();
   await page.getByRole('button',{name:'Start vurderingen',exact:true}).click();
   const group=packet.ordinary_assessments.find(x=>x.family==='services');
   for(let i=0;i<group.scenarios.length;i++){
    const s=group.scenarios[i];
    const section=page.getByRole('group',{name:s.student_visible_prompt_and_choices.split('\n')[0],exact:true});
    const p=s.proposed_pairs[s.scenario_id==='services-5'&&task==='services-paas'?1:0];
    await section.getByRole('combobox').nth(0).selectOption({label:p.decision});
    await section.getByRole('combobox').nth(1).selectOption({label:p.reason});
    log({kind:'select-pair',task,item:s.scenario_id,pair:p});
   }
   await capture(page,task+'-before-submit');
   await page.getByRole('button',{name:'Lever vurderingen',exact:true}).click();
   await page.getByText('Ingen innlevering i den oppdaterte vurderingen ennå.',{exact:true}).waitFor({state:'detached'});
   await capture(page,task+'-feedback');
  } else if(task.startsWith('transfer-')){
   await page.goto(base+'/learn/services?topic=transfer&case=cc18',{waitUntil:'networkidle'});
   await page.getByRole('button',{name:'Start selvstendig forsøk',exact:true}).click();
   await page.getByRole('button',{name:'Start selvstendig forsøk',exact:true}).nth(1).click();
   const s=packet.terminal_transfer_cases.find(x=>x.scenario_id==='cc18');
   const p=s.proposed_pairs[task==='transfer-iaas'?1:0];
   const reason=task==='transfer-mismatch'?s.proposed_pairs[1].reason:p.reason;
   await page.getByLabel(p.decision,{exact:true}).check();
   await page.getByLabel(reason,{exact:true}).check();
   log({kind:'select-pair',task,item:'cc18',pair:{decision:p.decision,reason}});
   await capture(page,task+'-before-submit');
   await page.getByRole('button',{name:'Lever beslutning og begrunnelse',exact:true}).click();
   await page.getByRole('button',{name:'Avbryt dette forsøket',exact:true}).waitFor({state:'detached'});
   await capture(page,task+'-feedback');
  } else {
   const routes={legacy:'/learn/services?topic=assessment&version=2&assessment=legacy',v1:'/learn/services?topic=overview&version=1',challenge:'/learn/services?topic=assessment&version=1',v1challenge:'/learn/services?topic=overview&version=1'};
   await page.goto(base+routes[task],{waitUntil:'networkidle'});log({kind:'navigate',task,url:page.url()});
   await capture(page,task+'-entry');
   if(task==='legacy'){
    await page.getByRole('button',{name:'Start egen besvarelse',exact:true}).click();
    await capture(page,'legacy-after-begin');
   }
   if(task==='v1challenge'){
    await page.getByRole('button',{name:'Independent challenge',exact:true}).click();
    await capture(page,'v1-challenge-brief');
    await page.getByRole('button',{name:'Start endret oppgave',exact:true}).click();
    await capture(page,'v1-challenge-questions');
   }
  }
  await context.close();
 }
 await browser.close();
})().catch(async e=>{log({kind:'error',message:e.message,stack:e.stack});console.error(e);await browser?.close();process.exitCode=1});
