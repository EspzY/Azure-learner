const { createRequire } = require('node:module');
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');
const pwRequire = createRequire('/workspace/Azure-learner/package.json');
const { chromium } = pwRequire('playwright');
const root = __dirname;
let browser;
let contexts = {};
let page;
let seq = Math.max(0,...fs.readdirSync(root).filter(f=>/^\d{3}-.*\.txt$/.test(f)).map(f=>Number(f.slice(0,3))));
const base = 'https://azure-learner-git-codex-az900-cloud-comp-3bf852-espzys-projects.vercel.app';
const log = x => fs.appendFileSync(path.join(root,'actions.jsonl'),JSON.stringify({...x,time:new Date().toISOString()})+'\n');
async function state(label='state') {
  const text = await page.locator('body').innerText();
  const file = `${String(++seq).padStart(3,'0')}-${label.replace(/[^a-z0-9-]/gi,'-')}`;
  fs.writeFileSync(path.join(root,file+'.txt'),text);
  await page.screenshot({path:path.join(root,file+'.png'),fullPage:true});
  const links = await page.getByRole('link').evaluateAll(els=>els.filter(e=>e.getClientRects().length).map(e=>({text:e.innerText,href:e.getAttribute('href')})));
  const buttons = await page.getByRole('button').evaluateAll(els=>els.filter(e=>e.getClientRects().length).map(e=>({text:e.innerText,disabled:e.disabled})));
  const out={file,url:page.url(),text,links,buttons}; log({kind:'state',...out});
  const start = text.indexOf('MODUL ');
  return {...out,text:start>=0?text.slice(start):text,links:links.filter(l=>!/^(#|\/learn$)/.test(l.href))};
}
async function run(a){
  log({kind:'command',command:a});
  if(a.op==='new'){
    const context = await browser.newContext({viewport:{width:1440,height:900}});
    page=await context.newPage();contexts[a.name]={context,page};
    page.on('pageerror', e=>log({kind:'pageerror',message:e.message}));
    page.on('requestfailed',r=>log({kind:'requestfailed',url:r.url(),error:r.failure()}));
    page.on('response',r=>{if(r.status()>=400) log({kind:'response-error',url:r.url(),status:r.status()});});
    await page.goto(a.url||base,{waitUntil:'networkidle'});
  } else if(a.op==='use'){page=contexts[a.name].page;}
  else if(a.op==='goto'){await page.goto(a.url.startsWith('http')?a.url:base+a.url,{waitUntil:'networkidle'});}
  else if(a.op==='click'){
    const locator=a.role?page.getByRole(a.role,{name:a.text,exact:a.exact!==false}):page.getByText(a.text,{exact:a.exact!==false});
    await locator.nth(a.nth||0).click();
    await page.waitForLoadState('networkidle');
  } else if(a.op==='fill') {await page.getByRole(a.role||'textbox',{name:a.name,exact:true}).fill(a.value);}
  else if(a.op==='select') {await page.getByRole('combobox',{name:a.name,exact:true}).selectOption({label:a.value});}
  else if(a.op==='viewport'){await page.setViewportSize({width:a.width,height:a.height});}
  else if(a.op==='scroll'){await page.getByText(a.text,{exact:a.exact!==false}).nth(a.nth||0).scrollIntoViewIfNeeded();}
  else if(a.op==='wait'){await page.waitForLoadState('networkidle');}
  else if(a.op==='quit'){await browser.close();process.exit(0);}
  return state(a.label||a.op);
}
(async()=>{
  browser=await chromium.launch({headless:true});
  const rl=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
  console.log('READY');
  for await(const line of rl){try{console.log(JSON.stringify(await run(JSON.parse(line))));}catch(e){const error={message:e.message,stack:e.stack};log({kind:'error',...error});console.log(JSON.stringify({error}));}}
})();
