/* Standalone replay of selected observed UI paths, prepared from commands.jsonl.
 * This clean replay was NOT executed end-to-end during the cold review, to avoid
 * creating additional simulator operations merely to recreate evidence.
 * Run from this directory with: node reproduce.cjs
 * Uses the preinstalled pinned Playwright Chromium. All resource effects are in
 * the app's anonymous local simulator. No independent assessment is started.
 */
const {createRequire}=require('module');
const r=createRequire('/workspace/Azure-learner/package.json');
const {chromium}=r('playwright');const fs=require('fs'),path=require('path');
const origin='https://azure-learner-git-codex-az900-cloud-comp-3bf852-espzys-projects.vercel.app';
const sha='527b95140917e75e83899f21e6b2291e01df0a7d';
(async()=>{
 const browser=await chromium.launch({headless:true});
 const context=await browser.newContext({viewport:{width:1440,height:900}});
 const page=await context.newPage();const out=path.join(__dirname,'reproduction');fs.mkdirSync(out,{recursive:true});let i=0;
 const snap=async(label)=>{const name=String(++i).padStart(2,'0')+'-'+label;await page.screenshot({path:path.join(out,name+'.png')});fs.writeFileSync(path.join(out,name+'.txt'),await page.locator('body').innerText());};
 const heading=async(name)=>page.getByRole('heading',{name,exact:true}).waitFor();
 const go=async(route,title)=>{await page.goto(origin+route);await heading(title);};
 await page.goto(origin+'/learn');await page.getByRole('link',{name:'Begynn med cloud computing',exact:true}).waitFor();
 await page.getByText('Bygginformasjon · forhåndsvisning',{exact:true}).click();
 if(!(await page.locator('body').innerText()).includes('Commit: '+sha))throw Error('Displayed SHA mismatch');await snap('sha');
 await page.getByRole('link',{name:'Begynn med cloud computing',exact:true}).click();await heading('Fra nettside til fysisk server');
 await page.getByRole('button',{name:'Send en forespørsel',exact:true}).click();await page.locator('button').filter({hasText:/^RAM/}).click();await snap('request-ram');
 await go('/learn/computing?topic=capacity-basics','Kapasitet og etterspørsel');
 await page.getByRole('spinbutton').fill('2');await page.getByRole('button',{name:'Registrer prediksjon og kjør',exact:true}).click();
 await page.getByText('10 pakker/time',{exact:true}).click();await page.getByRole('spinbutton').fill('0');await page.getByRole('button',{name:'Registrer prediksjon og kjør',exact:true}).click();await page.getByText('Vis de samme verdiene i tabell',{exact:true}).last().click();await snap('capacity-two-runs');
 await go('/learn/computing?topic=v2-responsibility','Ansvar når infrastrukturen blir en tjeneste');await page.getByRole('button',{name:'Kjør og sammenlign',exact:true}).click();await snap('repeated-responsibility-text');
 await go('/learn/benefits?topic=management','Gjenta en konfigurasjon — også feil kan gjentas');await page.locator('select').first().selectOption({label:'Én gjentatt malverdi'});await page.locator('select').last().selectOption('northeurope');await page.getByRole('button',{name:'Kjør undersøkelsen',exact:true}).click();await page.setViewportSize({width:1024,height:500});await page.emulateMedia({reducedMotion:'reduce'});await page.locator('select').first().focus();await page.keyboard.press('Tab');await snap('short-keyboard');
 await page.setViewportSize({width:1440,height:900});await page.emulateMedia({reducedMotion:'no-preference'});
 await go('/learn/computing?topic=resource-bridge','Fra forståelse til Portal-laboratoriet');await page.getByRole('button',{name:'Start praktisk lab',exact:true}).click();await page.getByRole('searchbox').waitFor();await page.getByRole('searchbox').fill('Resource groups');await page.getByText('Resource groups',{exact:true}).first().click();await heading('Resource groups');await page.getByRole('button',{name:'Create',exact:true}).click();await heading('Create a resource group');
 await page.locator('select[data-guide=subscription]').selectOption('sub-app');await page.locator('input[data-guide=name]').fill('rg-coldjourney-repro');await page.locator('select[data-guide=region]').selectOption('westeurope');await page.getByRole('button',{name:'Review + create',exact:true}).last().click();await page.getByRole('button',{name:'Create',exact:true}).click();await page.getByText('accepted · portal-1 · 0 → 1',{exact:false}).waitFor();await snap('accepted-group-unmet-metadata');
 await page.getByRole('link',{name:'App Service plans',exact:true}).click();await heading('App Service plans');await page.getByRole('button',{name:'Create',exact:true}).click();await heading('Create App Service Plan');await page.locator('select[data-guide=subscription]').selectOption('sub-app');await page.locator('select[data-guide=group]').selectOption({label:'rg-coldjourney-repro'});await page.locator('input[data-guide=name]').fill('plan-coldjourney-repro');await page.locator('select[data-guide=region]').selectOption('northeurope');await page.getByRole('button',{name:'Review + create',exact:true}).last().click();await page.getByRole('button',{name:'Create',exact:true}).click();await page.getByText('Teknisk årsak og tilstand',{exact:true}).waitFor();await snap('policy-rejection');
 await page.getByText('Undersøk gjeldende policy',{exact:true}).click();await heading('Policy');await snap('policy-scope');
 await browser.close();console.log('Replay complete: '+out);
})().catch(e=>{console.error(e);process.exitCode=1;});
