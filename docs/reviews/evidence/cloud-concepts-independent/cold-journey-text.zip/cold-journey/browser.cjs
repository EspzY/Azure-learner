const {createRequire}=require('module');
const requireApp=createRequire('/workspace/Azure-learner/package.json');
const {chromium}=requireApp('playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const base=__dirname;const events=[];let count=0;
(async()=>{
 const browser=await chromium.launch({headless:true});
 const context=await browser.newContext({viewport:{width:1440,height:900}});
 const page=await context.newPage();
 page.on('console',m=>{if(m.type()==='error')events.push({type:'console',text:m.text(),at:new Date().toISOString()})});
 page.on('pageerror',e=>events.push({type:'pageerror',text:e.message,at:new Date().toISOString()}));
 page.on('response',r=>{if(r.status()>=400)events.push({type:'http',url:r.url(),status:r.status(),at:new Date().toISOString()})});
 const snap=async(label)=>{const stamp=new Date().toISOString(), n=String(++count).padStart(3,'0'),name=n+'-'+label;const body=await page.locator('body').innerText();fs.writeFileSync(path.join(base,name+'.txt'),body);await page.screenshot({path:path.join(base,name+'.png'),fullPage:false});const data={name,at:stamp,url:page.url(),title:await page.title(),viewport:page.viewportSize(),scroll:await page.evaluate(()=>({x:scrollX,y:scrollY,height:document.documentElement.scrollHeight})),text:name+'.txt',screenshot:name+'.png'};fs.appendFileSync(path.join(base,'snapshots.jsonl'),JSON.stringify(data)+'\n');return {data,body};};
 const server=http.createServer(async(req,res)=>{let buf='';for await(const c of req)buf+=c;let cmd;try{cmd=JSON.parse(buf);fs.appendFileSync(path.join(base,'commands.jsonl'),JSON.stringify({at:new Date().toISOString(),...cmd})+'\n');const result=await new (Object.getPrototypeOf(async function(){}).constructor)('page','context','snap',cmd.code)(page,context,snap);fs.writeFileSync(path.join(base,'errors.json'),JSON.stringify(events,null,2));res.end(JSON.stringify({ok:true,result}));}catch(e){res.end(JSON.stringify({ok:false,error:String(e),stack:e.stack}));}});
 server.listen(8767,'127.0.0.1',()=>console.log('BROWSER_READY')); 
})();
