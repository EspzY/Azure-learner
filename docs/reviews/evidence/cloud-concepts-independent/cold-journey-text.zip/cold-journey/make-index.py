import json,hashlib,datetime
from pathlib import Path
root=Path('.')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
items=[json.loads(x) for x in Path('snapshots.jsonl').read_text().splitlines()]
for r in items:
 for field in ['text','screenshot']:r[field+'_sha256']=digest(Path(r[field]))
coverage=[]
def add(module, topic,title,evidence,status,interaction):
 coverage.append({'order':len(coverage)+1,'module':module,'route':f'/learn/{module}?topic={topic}','title':title,'coverage':status,'evidence':evidence,'executed_interaction':interaction})
cloud=[
('intro-request','Fra nettside til fysisk server','005','read','Send request first step, guided server-side answer and RAM/storage answer with feedback; select RAM'),
('virtualization','Virtualisering og bestilling av skykapasitet','007,008,009','read','Request5+4 memory with8 budget rejected; disable capacity and cloud provision request rejected; open SavvyShark tip'),
('capacity-basics','Kapasitet og etterspørsel','010,011','read','Prediction2 at6, then prediction0 at10; run both and open result table'),
('v2-responsibility','Ansvar når infrastrukturen blir en tjeneste','012,013,014','read','Compare; classify provider/customer/customer and reveal guided feedback'),
('v2-models','Cloud-modeller og valg av miljø','015,016','read','Hybrid diagram tab and text alternative'),
('v2-metering','Forbruk, betaling og risiko','017-022','read','Run idle and released compute; four steady/uncertain usage/commitment runs'),
('serverless-concept','Kode som venter på en hendelse','023','read','No response to concept question'),
('serverless-mechanism','Event → Trigger → Execution → Result','024','read','No response to concept question'),
('serverless-hosting','Ansvar, hosting og begrensninger','025','read','No response to concept question'),
('serverless-explorer','Undersøk en hendelseskjede','026-034','read','Open guided brief, warm7/2/2 prediction4 and code-error prediction3; cause question registered; visible guided feedback exposed'),
('serverless-assessment','Selvstendig anvendelse · Serverless','035','entrance-only','No attempt started'),
('serverless-summary','Ditt serverless-grunnlag','036','read','Summary inspected'),
('resource-bridge','Fra forståelse til Portal-laboratoriet','037-067','read','Portal representative chain: group, two accepted plans, one rejected attempt corrected, app, settingApply, receipt/policy/architecture; course return'),
('transfer','Prøv kunnskapen i nye situasjoner','068','entrance-only','No attempt started')]
for a in cloud:add('computing',*a)
benefits=[
('availability','Kapasitet er ikke det samme som tilgjengelighet','069-072','read','Healthy1x8→6, failed1x8→0, balanced2x4 onefailed→4; guided cause submitted'),
('reliability','Finn årsaken før du velger tiltak','073-075','read','Failed shared dependency: addcapacity→0, restoredependency→6; no full guided approval'),
('governance','Tillatelse, policy og sikkerhet er forskjellige spørsmål','076','read','No conceptual run; actual corresponding Portal policy inspected earlier'),
('management','Gjenta en konfigurasjon — også feil kan gjentas','077,078','read','Wrong NorthEurope repeated template: consistentYes, deviations3; shortviewport keyboard/media/Axe'),
('sustainability','Reduser unødvendig ressursbruk uten å fjerne funksjonen','079','read','No model run'),
('summary','Observasjoner og neste steg','080','read','Summary inspected'),
('transfer','Prøv kunnskapen i nye situasjoner','081','entrance-only','No attempt started')]
for a in benefits:add('benefits',*a)
services=[
('overview','Fra ansvarsoversikt til operativt valg','082-086','read','IaaS/PaaS/SaaS tabs, OS layer; SaaS depth/glossary'),
('iaas','Bygg en forståelig VM-konfigurasjon','087-089','read','Incomplete Linux4GiB etc; correct Windows8GiB persistentdata network/runtime patch plan; no VM practical creation'),
('paas','Kode, runtime og hosting er ulike deler','090','read','No conceptual model run; representative actual Portal earlier'),
('saas','Administrer en ferdig tjeneste, ikke en gjesteplattform','091,105-115','read','SaaS practical guided brief, seven commands incl license rejection, six accepted changes, history and guided reflection submitted; reload/return'),
('selection','Velg en løsning ut fra krav og driftsarbeid','092-094','read','Open webcode scenario accepts both IaaS+gueststack and PaaS+appwork rationales'),
('practice','Bruk og forklar den faktiske hostingkonfigurasjonen','095','read','Read technical incompletion/mismatch; no further Portal operations to force completion'),
('summary','Observasjoner og neste steg','096,100','read','Summary; browserBack'),
('transfer','Prøv kunnskapen i nye situasjoner','097,098,101,102','entrance-only','No attempt started; Journal then Back/Forward/reload')]
for a in services:add('services',*a)
Path('coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
index={
 'format':'cold-browser-evidence-v1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'deployment':{'origin':'https://azure-learner-git-codex-az900-cloud-comp-3bf852-espzys-projects.vercel.app','displayed_commit':'527b95140917e75e83899f21e6b2291e01df0a7d','verification':'003-build-info.txt/png; public build details clicked before teaching'},
 'provenance':{'workspace':'/workspace/azurelab-pr53/cold-journey','instructions_read':'AGENTS.md in this directory only; runtime skill/network policy','isolation':'procedural and context; OS permissions do not isolate application source, which was not read','method':'anonymous public UI; Playwright installed dependency via createRequire; installed pinned Chromium chromium-1248; no new framework','person':'AI expert critic; no human novice or measured learning claim','viewports':[{'width':1440,'height':900},{'width':1024,'height':500}],'guided_feedback_exposed':True,'independent_attempts_started':False,'independent_keys_or_feedback_read':False,'source_files_read':False},
 'coverage':coverage,'snapshots':items,
 'actions_log':{'path':'commands.jsonl','sha256':digest(Path('commands.jsonl')),'note':'Exact attempted browser command chronology. Includes selector errors, transient route snapshots and some overlapping outstanding selector waits; not all attempts completed. Definitive outcomes are supported by DOM text/receipts/screenshots, not inferred from commands.'},
 'browser_errors':json.loads(Path('errors.json').read_text()),
 'incidents':[{'type':'reviewer-harness','description':'Several incorrect role/exact-name selectors timed out or strict-mode failed. These are not classified as app failures. Pending requests were sometimes followed by DOM inspection; overlapping wait commands can complete late. No intentional retry strategy or raised timeout/workers used.'},{'type':'transient-ui','description':'Immediate route-change screenshots sometimes show prior body or assessment-context guard. Later settled snapshots supersede these, not classified as persistent blocked teaching.'},{'type':'environment','at_approx':'2026-11-04T06:30Z','description':'One exec invocation failed: exec-server transport disconnected during pending Portal reload verification. Later tool recovery confirmed APP_ENVIRONMENT=staging after reload in064; not an app-network defect.'}],
 'checks':{'axe':{'path':'axe-management-short.json','sha256':digest(Path('axe-management-short.json')),'scope':'/learn/benefits?topic=management,1024x500,reducedMotion reduce','violations':0,'incomplete':['color-contrast']},'keyboard':'078 Tab moved from configmethod to templatevalue with visible ring;099 Escape closed Journal and restored Knowledge Journal button focus','network':'No recorded HTTP>=400 or pageerror. Four CSP console errors block optional vercel.live feedback script. Not proof of all network correctness.'},
 'omissions':['No independent scenario started, solved, submitted or feedback read','VM practical and four changed independent practical missions not executed; inline prompts read','No exhaustive model parameter combinations or all component tabs','No complete sources drawer expansion/external official-link validation','No mobile, screenreader, full keyboard audit, manual contrast measurement or full reduced-motion animation audit','No cloud/auth/backend/storage tampering tests; no real Azure effect asserted','No SME/API verification of service-specific contracts; current app itself says qualified human validation remains']}
Path('index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print('index.json',digest(Path('index.json')),'activities',len(coverage))
