const {chromium}=require('/workspace/Azure-learner/node_modules/@playwright/test');
const readline=require('readline');
const fs=require('fs');
(async()=>{
const started=new Date().toISOString();
const browser=await chromium.launch({headless:true});
const context=await browser.newContext({viewport:{width:1440,height:1080}});
const page=await context.newPage();
await page.goto('https://azure-learner-git-codex-az900-cloud-comp-3bf852-espzys-projects.vercel.app/portal?area=challenge&module=services&topic=overview&mode=independent&course=1',{waitUntil:'networkidle'});
const log=x=>{console.log(JSON.stringify(x));fs.appendFileSync('/workspace/azurelab-pr53/legacy-cold/ui-observations.jsonl',JSON.stringify(x)+'\n');};
log({event:'FIRST_REVIEW_VIEW',started,at:new Date().toISOString(),url:page.url(),title:await page.title(),text:await page.locator('body').innerText()});
const rl=readline.createInterface({input:process.stdin,output:process.stdout});
for await(const line of rl){
try{const c=JSON.parse(line);
if(c.action==='read')log({event:'READ',at:new Date().toISOString(),url:page.url(),text:await page.locator('body').innerText(),controls:await page.locator('button,input,select,textarea,[title]').evaluateAll(es=>es.filter(e=>e.getClientRects().length).map(e=>({tag:e.tagName,text:e.innerText,type:e.type,name:e.name,title:e.title,ariaLabel:e.getAttribute('aria-label'),value:e.value,options:e.tagName==='SELECT'?[...e.options].map(o=>({text:o.text,value:o.value})):undefined})))});
if(c.action==='click'){await page.getByRole('button',{name:c.name,exact:true}).click();await page.waitForTimeout(750);log({event:'CLICKED',name:c.name,at:new Date().toISOString(),url:page.url(),text:await page.locator('body').innerText()});}
if(c.action==='hoverText'){await page.getByText(c.text,{exact:true}).hover();await page.waitForTimeout(750);log({event:'HOVERED',text:c.text,at:new Date().toISOString(),visibleText:await page.locator('body').innerText()});}
if(c.action==='screenshot'){await page.screenshot({path:c.path,fullPage:true});log({event:'SCREENSHOT',path:c.path,at:new Date().toISOString()});}
if(c.action==='close'){await browser.close();rl.close();break;}
}catch(e){log({error:e.message});}
}
})();
