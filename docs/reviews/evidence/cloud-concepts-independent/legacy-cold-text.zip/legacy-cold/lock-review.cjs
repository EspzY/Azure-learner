const fs=require('fs');
const crypto=require('crypto');
const dir='/workspace/azurelab-pr53/legacy-cold';
const events=fs.readFileSync(dir+'/ui-observations.jsonl','utf8').trim().split('\n').map(JSON.parse);
const current=events.find(e=>e.event==='READ' && e.controls?.some(c=>c.tag==='SELECT'));
const expected='527b95140917e75e83899f21e6b2291e01df0a7d';
const lockedAt=new Date().toISOString();
const questions=[
 {id:'os-dependent',prompt:'Hvilken modell passer OS-avhengig programvare?',options:['Velg et svar','IAAS','PAAS','SAAS'],answer:'IAAS',confidence:'conditional; wording alone does not establish unique correctness',reasoning:'IaaS is a sensible choice if the software requires guest-OS control, custom system configuration, unsupported runtime components, or installation privileges. None of those distinguishing requirements is explicitly stated. OS dependence alone is insufficient: a compatible managed PaaS runtime also runs on an OS.',missingPremises:['The particular OS dependency and whether the team must control the guest OS.','Whether that dependency is supported by an available managed runtime/platform.'],validAlternatives:['PAAS if the software and its OS/runtime dependencies are supported by the managed platform.','SAAS only if a ready hosted product already supplies the required functions; the phrase OS-dependent by itself does not exclude this, although no such product fit is stated.']},
 {id:'own-http',prompt:'Hvilken modell passer teamets egen HTTP-kode?',options:['Velg et svar','IAAS','PAAS','SAAS'],answer:'PAAS',confidence:'high under the normal service-model reading',reasoning:'The team supplies its own HTTP application and expressly wants no guest-OS maintenance. A managed application platform fits this division of responsibility.',missingPremises:['Compatibility of the application runtime and other dependencies with the selected platform is implicit rather than stated.'],validAlternatives:['Different managed application-hosting or serverless offerings within PaaS could satisfy these stated workload requirements; no single concrete product is established solely by this question.']},
 {id:'ready-collaboration',prompt:'Hvilken modell passer ferdig samarbeid?',options:['Velg et svar','IAAS','PAAS','SAAS'],answer:'SAAS',confidence:'high if ferdig means an already supplied application',reasoning:'A ready collaboration application consumed for its functions fits SaaS. The short wording signals an outcome supplied as a product rather than a team-developed application.',missingPremises:['The needed collaboration functions and whether an existing hosted product meets them.','An explicit statement that the team consumes a ready application rather than deploying a prebuilt self-hosted package.'],validAlternatives:['IAAS or PAAS could host a ready-made collaboration package if self-hosting were required. The text does not explicitly rule that interpretation out.']},
 {id:'http-cause',prompt:'Hva begrunner valget for HTTP-koden?',options:['Velg et svar','Arbeidslasten krever kontroll over gjeste-OS.','Teamet leverer egen kode på en støttet, administrert plattform.','Behovet er en ferdig applikasjon med støttede funksjoner.'],answer:'Teamet leverer egen kode på en støttet, administrert plattform.',confidence:'high among displayed choices; supported-platform compatibility is assumed',reasoning:'Own code plus provider-managed guest OS is the relevant PaaS boundary. The OS-control option conflicts with the requested lack of guest-OS maintenance. The ready-application option does not match the team supplying its own HTTP application.',missingPremises:['That the code and dependencies are in fact supported by the managed platform. This support is introduced by the answer option, not expressly established by the task premise.'],validAlternatives:[]},
 {id:'app-location',prompt:'Hva avgjør appens resource location?',options:['Velg et svar','Den refererte hosting-planens lokasjon.','Alltid resource groupens metadata-region.','Én global policy bestemmer lokasjonen i alle subscriptions.'],answer:'Den refererte hosting-planens lokasjon.',confidence:'high in the displayed App Service plan / Web App context',reasoning:'The hosting plan supplies the App Service app hosting region. With hosting required in North Europe and group metadata in Norway East, a North Europe plan yields North Europe app hosting. A resource group metadata region does not force all grouped resources into that region.',missingPremises:['The explicit generic phrase resource location is interpreted through the adjacent App Service plan and Web App selectors. It should not be generalized to every Azure resource type.'],validAlternatives:[]}
];
const packet={
 schemaVersion:1,
 assessmentType:'Genuinely blind learner-facing, expert-AI-only review; not a human novice study',
 route:current.url,
 expectedBuildSha:expected,
 observedBuildSha:null,
 observedVersionText:'AzureLab 3.2.1',
 buildVerification:'No full SHA was displayed in the assessment body, visible control titles, or after hovering AzureLab 3.2.1. The supplied expected SHA is recorded as unverified; no source, API, or deployment metadata was inspected.',
 timings:{firstBrowserLaunchStartedAt:'2026-11-04T06:45:05.207Z',firstLearnerViewAt:'2026-11-04T06:45:07.856Z',reviewBrowserLaunchStartedAt:'2026-11-04T06:45:37.565Z',reviewLearnerViewAt:'2026-11-04T06:45:39.967Z',questionsRevealedAt:'2026-11-04T06:45:46.235Z',lockedAt,questionExposureToLockSeconds:Math.round((Date.parse(lockedAt)-Date.parse('2026-11-04T06:45:46.235Z'))/1000)},
 context:{freshAnonymous:true,browser:'Chromium via installed @playwright/test 1.64.1',viewport:{width:1440,height:1080},language:'Norwegian learner text',introSeenTwice:true,restartReason:'The initial node heredoc did not retain interactive stdin; it was stopped, and a new browser/new context was launched. The initial view revealed only the same assessment introduction.',sourceAccess:'Only the authorized package.json dependency entry and installed Playwright were used. No application source, existing reviewer output, answer keys, rubrics, reports, hidden app state, or network response bodies were inspected.',storageInjection:false,applicationFilesChanged:false,resourcesCreated:false,answersSelectedInUI:false,submitted:false,feedbackOrHelpOpened:false},
 visibleTitle:'Et nytt team · samme tekniske modell',
 exactPremise:'Et nytt team trenger en ny, egen HTTP-applikasjon uten gjeste-OS-vedlikehold. Bruk Shared Sandbox. Gruppemetadata skal være i Norway East, men hosting skal være i North Europe. Bygg ny gruppe, plan og app i dette forsøket; velg egne navn. To andre krav gjelder OS-avhengig programvare og ferdig samarbeid. Du får kravene, ikke konfigurasjonstrinnene.',
 exactWarning:'Endret krav uten fremgangsmåte. Teori, sammenligning eller hint under forsøket registreres som hjelp.',
 exactAttemptNotice:'Oppgaven pågår. Ressursarbeidet og svarutkastet lagres. Ingen registrert hjelp i dette forsøket. Dette attesterer ikke identitet eller hva du brukte utenfor AzureLab.',
 unavoidableUiTeachingExposure:['The initial premise supplies the own-code / no-guest-OS-maintenance distinction.','The causal answer choices themselves name guest-OS control, supported managed platform, and ready application, revealing the usual service-model decision boundaries while all five questions are visible together.','Resource-selector labels explicitly name App Service plan and Web App, supplying product context for the app-location question.','Portal navigation names other learning tools, but no such tools, feedback, help, or explanations were opened.'],
 questions,
 resourceSelectors:[{prompt:'Resource group',options:['Velg et svar'],answer:null},{prompt:'App Service plan',options:['Velg et svar'],answer:null},{prompt:'Web App',options:['Velg et svar'],answer:null}],
 resourceSelectorDisposition:'All three contained only the blank placeholder. No resources were invented or selected. The resource-building portion was outside this audit-only scope.',
 exactPostStartUiText:current.text,
 stopCondition:'Independent responses locked before any answer submission, feedback, accepted-answer inspection, or external review output. Await explicit follow-up.'
};
const md=[
 '# Legacy blind solve — locked before feedback',
 '',
 'This is an expert AI learner-facing review, not a human novice assessment. Filesystem/tool access is shared; isolation was procedural. I did not read other reviewer outputs or application implementation, reports, answer keys, or rubrics. No feedback/help was opened and nothing was submitted.',
 '',
 `- Route: ${packet.route}`,
 `- Supplied expected build SHA: ${expected}`,
 '- Displayed version: AzureLab 3.2.1. The full build SHA was not visible on this assessment, including after hovering the version text. I cannot honestly claim to have verified the supplied SHA from the learner UI.',
 `- First learner view: ${packet.timings.firstLearnerViewAt}. Questions exposed: ${packet.timings.questionsRevealedAt}. Lock: ${lockedAt}.`,
 `- Actual question exposure to lock: ${packet.timings.questionExposureToLockSeconds} seconds. These are wall-clock timestamps, not an estimate of human completion time.`,
 '- A browser restart repeated the same introductory assessment text. Each Chromium context was fresh and anonymous. Only Start endret oppgave was clicked; the version label was hovered. No answer selector changed, resource created, storage injected, or submit/feedback/help action occurred.',
 '',
 '## Exact premise',
 '',
 packet.exactPremise,
 '',
 packet.exactWarning,
 '',
 '## Independent answers and uncertainty',
 '',
 ...questions.flatMap((q,i)=>[
 `### ${i+1}. ${q.prompt}`,'',
 ...q.options.map(o=>`- ${o}`),'',
 `Locked choice: **${q.answer}**. Confidence: ${q.confidence}.`,'',q.reasoning,'',
 `Missing premises: ${q.missingPremises.join(' ')}`,'',
 `Valid alternatives: ${q.validAlternatives.length?q.validAlternatives.join(' '):'No equally valid displayed alternative under the stated App Service context.'}`,'']),
 '## Resource selectors and exposure limits','',
 'Resource group, App Service plan, and Web App each had only the option “Velg et svar”. All remained blank. No resources were invented. Resource construction was outside the audit-only authorization.','',
 ...packet.unavoidableUiTeachingExposure.map(x=>`- ${x}`),'',
 'Because the whole question set is visible together, this is blind to accepted answers but not free of answer-option teaching. The OS-dependent premise is the clearest ambiguity: an OS dependency does not by itself require customer OS control. The collaboration item also omits the product-fit and hosted-consumption premises.','',
 '## Complete learner-visible assessment after Start','',
 '```text',current.text,'```','',
 'STOP: responses were locked before feedback, submission, or accepted-answer inspection. Await explicit follow-up.',''
].join('\n');
fs.writeFileSync(dir+'/student-packet.json',JSON.stringify(packet,null,2)+'\n');
fs.writeFileSync(dir+'/LEGACY_BLIND_SOLVE.md',md);
const hashes={};
for(const name of ['LEGACY_BLIND_SOLVE.md','student-packet.json']){hashes[name]=crypto.createHash('sha256').update(fs.readFileSync(dir+'/'+name)).digest('hex');fs.chmodSync(dir+'/'+name,0o444);}
const lock={lockedAt,algorithm:'sha256',expectedBuildSha:expected,observedBuildSha:null,shaVerification:'Expected supplied SHA not displayed or verified in learner UI',files:hashes};
fs.writeFileSync(dir+'/lock.json',JSON.stringify(lock,null,2)+'\n');
fs.chmodSync(dir+'/lock.json',0o444);
console.log(JSON.stringify(lock,null,2));
console.log('lock.json sha256 '+crypto.createHash('sha256').update(fs.readFileSync(dir+'/lock.json')).digest('hex'));
console.log(['LEGACY_BLIND_SOLVE.md','student-packet.json','lock.json'].map(n=>({file:n,mode:(fs.statSync(dir+'/'+n).mode&0o777).toString(8)})));
