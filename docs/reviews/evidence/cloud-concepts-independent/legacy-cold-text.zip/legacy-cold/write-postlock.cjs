const fs=require('fs');
const crypto=require('crypto');
const dir='/workspace/azurelab-pr53/legacy-cold';
const locked=JSON.parse(fs.readFileSync(dir+'/lock.json','utf8'));
const build=JSON.parse(fs.readFileSync(dir+'/postlock-build-ui.json','utf8'));
const sha=build.after.text.match(/Commit: ([0-9a-f]{40})/)[1];
const checks=Object.fromEntries(Object.entries(locked.files).map(([file,expected])=>{const actual=crypto.createHash('sha256').update(fs.readFileSync(dir+'/'+file)).digest('hex');return [file,{expected,actual,matches:actual===expected}];}));
const lockSha=crypto.createHash('sha256').update(fs.readFileSync(dir+'/lock.json')).digest('hex');
const excerpt=(path,start,end)=>fs.readFileSync(path,'utf8').split('\n').slice(start-1,end).map((s,i)=>`${start+i}: ${s}`).join('\n');
const excerpts='Post-lock authorized source excerpts only\nCaptured: '+new Date().toISOString()+'\n\n/workspace/Azure-learner/src/domain/portal/learning.ts:202–240\n'+excerpt('/workspace/Azure-learner/src/domain/portal/learning.ts',202,240)+'\n\n/workspace/Azure-learner/src/content/nb.ts:2528–2569\n'+excerpt('/workspace/Azure-learner/src/content/nb.ts',2528,2569)+'\n';
fs.writeFileSync(dir+'/postlock-source-excerpts.txt',excerpts);
const md=`# Post-lock comparison

This addendum was prepared only after the blind solve was locked at ${locked.lockedAt} and the parent explicitly authorized build verification and the two source excerpts. The original report, packet, lock, UI log, and initial screenshot were preserved. No answer was selected or submitted in either browser session, and no resource was created. The owner's missing-premise concern was supplied after the blind lock.

## Separate build verification

- A new anonymous Chromium context navigated to the same public host's ordinary root. The site redirected to \`/learn\`.
- Opening the visible “Bygginformasjon · forhåndsvisning” control displayed, at ${build.after.at}:

\`\`\`text
Commit: ${sha}

Gren: codex/az900-cloud-computing-consolidation
\`\`\`

The full displayed SHA matches the supplied expected SHA. This verification happened after the blind solve; it does not alter the original report's accurate statement that the assessment page itself did not expose a full SHA.

Evidence: [root UI text and timestamps](postlock-build-ui.json) and [opened build-information screenshot](postlock-build-info.png). The root page also exposed its ordinary course overview after the lock; no learning module, help, or assessment feedback was opened.

## OS-dependent item versus acceptance

The locked learner-visible question was “Hvilken modell passer OS-avhengig programvare?” The brief added only that two other requirements concern “OS-avhengig programvare og ferdig samarbeid.” Neither stated that this workload requires customer control of the guest OS, OS installation privileges, a custom kernel, unsupported system dependencies, or another constraint that excludes a compatible managed platform.

The now-authorized local acceptance excerpt contains:

\`\`\`ts
os: a.osModel === 'iaas',
\`\`\`

The corresponding local content criterion says:

\`\`\`text
OS-kontroll: IaaS passer det endrede kravet.
\`\`\`

This establishes that the inspected acceptance implementation requires IaaS for the OS criterion. Its feedback wording assumes OS control, a stronger service-selection premise than the learner-visible OS dependence.

My already locked choice was **IAAS**, explicitly conditional on the application requiring guest-OS control or an unsupported dependency. My locked **PAAS** alternative was explicitly conditional on the software and OS/runtime dependencies being supported by a managed platform. Both positions depend on facts absent from the visible requirement. A program being OS-dependent does not itself distinguish those cases, because managed platforms also run OS-dependent programs within their supported environments.

The finding is therefore under-specification of service selection. It does not establish that every OS-dependent application belongs on PaaS, or that the locked IaaS choice is universally justified by the prompt. I submitted neither the conditional IaaS answer nor a PaaS alternative. No accepted alternative, false rejection, passing assessment, or runtime scoring outcome was demonstrated. Under the inspected equality, a PaaS value would not satisfy the OS criterion; that is a source-level observation only.

The same limited acceptance excerpt also requires the HTTP model to be PaaS with the managed-platform reason and ready collaboration to be SaaS, matching my locked choices for those items. I inspected only the authorized source ranges. The local source checkout's provenance was not independently established by this narrow review; the deployed page's displayed SHA was verified separately above.

## Preservation check

- Original report SHA-256: \`${checks['LEGACY_BLIND_SOLVE.md'].actual}\` (${checks['LEGACY_BLIND_SOLVE.md'].matches?'matches lock':'MISMATCH'}).
- Original packet SHA-256: \`${checks['student-packet.json'].actual}\` (${checks['student-packet.json'].matches?'matches lock':'MISMATCH'}).
- Original lock SHA-256: \`${lockSha}\` (matches the previously reported lock digest).

Source evidence: [authorized numbered excerpts](postlock-source-excerpts.txt). All post-lock observations use separate files. No application source/runtime change or technical-resource action occurred.
`;
fs.writeFileSync(dir+'/POSTLOCK_COMPARISON.md',md);
const artifactNames=['POSTLOCK_COMPARISON.md','postlock-build-ui.json','postlock-build-info.png','postlock-source-excerpts.txt'];
const evidence={createdAt:new Date().toISOString(),blindLockAt:locked.lockedAt,displayedBuildSha:sha,expectedBuildSha:locked.expectedBuildSha,buildMatches:sha===locked.expectedBuildSha,originalChecks:checks,originalLockSha256:lockSha,artifacts:Object.fromEntries(artifactNames.map(f=>[f,crypto.createHash('sha256').update(fs.readFileSync(dir+'/'+f)).digest('hex')]))};
fs.writeFileSync(dir+'/postlock-evidence.json',JSON.stringify(evidence,null,2)+'\n');
for(const name of [...artifactNames,'postlock-evidence.json'])fs.chmodSync(dir+'/'+name,0o444);
console.log(JSON.stringify(evidence,null,2));
