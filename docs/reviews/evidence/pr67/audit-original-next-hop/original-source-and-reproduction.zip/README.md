# Original next-hop ambiguity finding

Captured 8 November 2026, before correction. These are outside-repository evidence copies; do not edit them to match corrected source.

`reproduce.sh` preserves the exact successful in-memory all-command reproduction. `result.json` preserves that command's observed stdout. The script loads actual repository modules at execution time; rerunning it after a correction is expected to produce different results. The original implementation and real-command fixture are copied here to bind the finding to source. There is no World injection, server, database or external call in this reproduction.

Source SHA-256:

- `analysis.ts`: `2520e5c06b9fa1a140ec9d491bfc6b3657e3aa7bc3736f3073433c9698643896`
- `topology.ts`: `7fa39dc3e794dbb3c7e2f116759fa0e33244518aa15cde119276358762d7038c`
- `domain.ts`: `aa1d03e41501ffe1f671f94b4d9f4d8a0f44091e87105a1dfa82ab7b4d407f43`
- `contract.ts`: `feba30e0371298fd855ed8a0eb8e668cd5924d68a3f645a261e01b610602f2fa`
- `projection.ts`: `18ab770dce0ef3ab28d2bce58b55bd0984a3db9e7d7aae617bf3183cd8721a67`
- `firewall-world.ts`: `059455fe05070aa8d46b56f76e536b73cd4dc2bfcd07870cce515eea2fecfd4d`

The first exploratory invocation also attempted a VnetLocal route outside the source VNet and correctly threw `unsupported-route-profile` before printing its buffered results. The retained successful reproduction omits that unrelated invalid exploratory command. Its successful output, not the failed exploratory invocation, establishes the two false-positive paths.
